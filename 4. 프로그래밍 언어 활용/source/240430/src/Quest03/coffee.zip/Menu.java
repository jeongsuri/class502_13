package Quest03;

public class Menu {
    public static final int STARAMERICANO = 4000;
    public static final int STARLATTE = 4300;
    public static final int CONGAMERICANO = 4100;
    public static final int CONGLATTE = 4500;
}
