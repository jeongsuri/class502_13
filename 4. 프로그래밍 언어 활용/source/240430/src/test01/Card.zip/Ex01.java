package test01;



public class Ex01 {
    public static void main(String[] args) {
        Card card1 = new Card();
        Card card2 = new Card();
        Card card3 = new Card();
        System.out.println(card1.getCardId());
        System.out.println(card2.getCardId());
        System.out.println(card3.getCardId());
    }
}
